function AdicionaTarefa(){
    alert("Função para adicionar uma tarefa!");
}

function ExcluirTodas(){
    alert("Função para excluir todas as tarefas!");
}

function SalvarTarefas(){
    alert("Função para salvar todas as tarefas!");
}

function CarregarTarefas(){
    alert("Função para carregar todas as tarefas!");
}